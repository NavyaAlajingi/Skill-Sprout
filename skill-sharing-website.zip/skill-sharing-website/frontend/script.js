const apiUrl = 'http://localhost:5000'; // Change this if your backend URL is different

// REGISTER USER
document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const userData = {
                name: document.getElementById('name').value,
                email: document.getElementById('email').value,
                phone: document.getElementById('phone').value,
                role: document.getElementById('role').value,
                skill: document.getElementById('skill').value,
                skillLevel: document.getElementById('skillLevel').value,
                password: document.getElementById('password').value
            };

            try {
                const response = await fetch(`${apiUrl}/auth/register`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(userData)
                });

                const result = await response.json();
                alert(result.message);
                if (response.ok) {
                    window.location.href = 'login.html';
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Registration failed!');
            }
        });
    }

    // LOGIN USER
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const loginData = {
                email: document.getElementById('email').value,
                password: document.getElementById('password').value
            };

            try {
                const response = await fetch(`${apiUrl}/auth/login`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(loginData)
                });

                const result = await response.json();
                if (response.ok) {
                    localStorage.setItem('token', result.token);
                    localStorage.setItem('user', JSON.stringify(result.user));
                    alert('Login successful!');
                    window.location.href = 'welcome.html';
                } else {
                    alert(result.message);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Login failed!');
            }
        });
    }

    // SEARCH SKILLS
    const searchSkills = async () => {
        const skill = document.getElementById('skillSearch').value;
        try {
            const response = await fetch(`${apiUrl}/auth/search?skill=${skill}`, {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
            });

            const users = await response.json();
            const resultsDiv = document.getElementById('results');
            resultsDiv.innerHTML = '';

            if (users.length === 0) {
                resultsDiv.innerHTML = '<p>No users found with this skill.</p>';
                return;
            }

            users.forEach(user => {
                const userCard = document.createElement('div');
                userCard.innerHTML = `
                    <p><strong>${user.name}</strong> - ${user.skill} (${user.skillLevel})</p>
                    <p>Contact: ${user.email} | ${user.phone}</p>
                    <hr>
                `;
                resultsDiv.appendChild(userCard);
            });
        } catch (error) {
            console.error('Error:', error);
            alert('Error fetching skill users!');
        }
    };

    window.searchSkills = searchSkills;
});
