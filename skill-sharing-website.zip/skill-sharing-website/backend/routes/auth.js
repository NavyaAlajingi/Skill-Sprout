const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

const router = express.Router();

// Register Route
router.post("/register", async (req, res) => {
    try {
        const { name, email, phone, role, skill, skillLevel, password, image } = req.body;

        console.log("➡️ Register request received:", req.body);

        // Check if user already exists
        let user = await User.findOne({ email });
        if (user) return res.status(400).json({ message: "User already exists" });

        // Hash password
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(password, salt);

        // Create new user
        user = new User({
            name,
            email,
            phone,
            role,
            skill,
            skillLevel,
            password: hashedPassword,
            image
        });

        await user.save();
        res.status(201).json({ message: "User registered successfully" });
    } catch (err) {
        console.error("🔥 Registration Error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

// Login Route
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;
        console.log("➡️ Login request received:", req.body);

        // Check if user exists
        const user = await User.findOne({ email });
        if (!user) return res.status(400).json({ message: "User not found" });

        // Check password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ message: "Invalid credentials" });

        // Generate token
        const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: "1h" });
        res.json({ token, user });
    } catch (err) {
        console.error("🔥 Login Error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

// Get User Profile
router.get("/profile/:id", async (req, res) => {
    try {
        console.log("➡️ Fetching profile for user ID:", req.params.id);
        const user = await User.findById(req.params.id).select("-password");
        if (!user) return res.status(404).json({ message: "User not found" });
        res.json(user);
    } catch (err) {
        console.error("🔥 Profile Fetch Error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

// Search Users by Skill
router.get("/search", async (req, res) => {
    try {
        const { skill } = req.query;
        if (!skill) return res.status(400).json({ message: "Skill is required" });

        console.log("➡️ Searching users with skill:", skill);
        const users = await User.find({ skill: { $regex: new RegExp(skill, "i") } }).select("-password");
        res.json(users);
    } catch (err) {
        console.error("🔥 Search Error:", err);
        res.status(500).json({ message: "Server error", error: err.message });
    }
});

module.exports = router;
