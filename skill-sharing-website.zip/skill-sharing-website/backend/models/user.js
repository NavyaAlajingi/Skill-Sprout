const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    phone: { type: String, required: true },
    role: { type: String, required: true, enum: ["Skill Planter", "Skill Cultivator"] },
    skill: { type: String, required: true },
    skillLevel: { type: String, required: true, enum: ["Beginner", "Intermediate", "Advanced", "Expert", "Master"] },
    password: { type: String, required: true },
    image: { type: String, default: "" }
});

module.exports = mongoose.model("User", UserSchema);
